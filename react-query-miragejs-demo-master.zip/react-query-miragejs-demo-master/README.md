# this is a demo of react-query + mirage.js

Hosted at https://react-query-miragejs-demo.netlify.com/

![reactquery2](https://user-images.githubusercontent.com/6764957/75601245-6cc29e00-5a87-11ea-80ab-1602c885f26b.gif)

instructions


```bash
yarn
yarn start
```
