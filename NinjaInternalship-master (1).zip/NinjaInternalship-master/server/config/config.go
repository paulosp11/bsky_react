package config

const (
	host     = "localhost"
	port     = 6432
	user     = "cryptoapp"
	password = "dev"
	dbname   = "cryptoapp"
)
