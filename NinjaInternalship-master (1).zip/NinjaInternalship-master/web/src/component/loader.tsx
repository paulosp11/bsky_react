import React from "react"
interface Props {}

function Loader(props: Props) {
	const {} = props

	return <div>{""}</div>
}

export default Loader
