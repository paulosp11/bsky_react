export interface IUser {
	id: string
	email: string
	password: string
	isSubmitting: boolean
	message: string	
}

