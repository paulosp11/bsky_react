# basic-react-form

[Watch the YouTube video to learn how it was made.](https://youtu.be/WHqd12n2n7M)
