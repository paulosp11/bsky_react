import React from 'react'
import { DiaryList } from '../diary/diary'

 const Home = () => {
    return (
        <div>
            <DiaryList/>
        </div>
    )
}
export default Home