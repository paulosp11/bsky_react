export enum TypeTodo {
    typeA = "TYPE A",
    typeB = "TYPE B",
    typeC = "TYPE C"
}